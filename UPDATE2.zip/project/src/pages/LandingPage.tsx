import LandingHero from '../components/LandingHero';

const LandingPage = () => {
  return <LandingHero />;
};

export default LandingPage;